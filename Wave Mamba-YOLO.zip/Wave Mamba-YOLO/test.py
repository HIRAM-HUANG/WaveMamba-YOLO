import numpy as np
import matplotlib.pyplot as plt

# 数据
labels = ['mAP50', 'mAP50-95', 'Recall', 'Precision']
yolov11n = np.array([49.5, 22.7, 48.8, 55.2])
yolov11n_chdwt = np.array([50.5, 23.5, 49.6, 56.1])

# 非线性缩放函数
def scale_radius(value, low=22, high=57):
    if value < low:
        return value * 0.5
    elif value > high:
        return low + (value - high) * 0.5 + (high - low)
    else:
        return low + (value - low) * 2

yolov11n_scaled = np.array([scale_radius(v) for v in yolov11n])
yolov11n_chdwt_scaled = np.array([scale_radius(v) for v in yolov11n_chdwt])

# 闭合数据
yolov11n_scaled = np.append(yolov11n_scaled, yolov11n_scaled[0])
yolov11n_chdwt_scaled = np.append(yolov11n_chdwt_scaled, yolov11n_chdwt_scaled[0])

# 角度
angles = np.linspace(0, 2*np.pi, len(labels), endpoint=False).tolist()
angles += angles[:1]

# 创建雷达图
fig, ax = plt.subplots(figsize=(7,7), subplot_kw=dict(polar=True))

# Nature 风格配色
color1 = '#4C72B0'  # 蓝色
color2 = '#C44E52'  # 红色

# 绘制曲线
ax.plot(angles, yolov11n_scaled, 'o-', linewidth=2, color=color1, zorder=3)
ax.plot(angles, yolov11n_chdwt_scaled, 's-', linewidth=2, color=color2, zorder=3)

# 填充区域
ax.fill(angles, yolov11n_scaled, alpha=0.12, color=color1, zorder=1)
ax.fill(angles, yolov11n_chdwt_scaled, alpha=0.12, color=color2, zorder=2)

# 设置标签
ax.set_xticks(angles[:-1])
ax.set_xticklabels(labels, fontsize=12, fontweight='medium')

# 设置径向范围
max_radius = max(max(yolov11n_scaled), max(yolov11n_chdwt_scaled))
ax.set_ylim(0, max_radius * 1.15)

# 数值标注（错开，最后一个点单独偏移）
offset = max_radius * 0.03
for i in range(len(labels)):
    if i == len(labels)-1:  # 最后一个点 Precision
        ax.text(angles[i]-0.03, yolov11n_scaled[i] - offset*1.5, f"{yolov11n[i]:.1f}",
                color=color1, fontsize=10, ha='right', va='top')
        ax.text(angles[i]+0.03, yolov11n_chdwt_scaled[i] + offset*1.5, f"{yolov11n_chdwt[i]:.1f}",
                color=color2, fontsize=10, ha='left', va='bottom')
    else:
        ax.text(angles[i], yolov11n_scaled[i] - offset, f"{yolov11n[i]:.1f}",
                color=color1, fontsize=10, ha='center', va='top')
        ax.text(angles[i], yolov11n_chdwt_scaled[i] + offset*1.2, f"{yolov11n_chdwt[i]:.1f}",
                color=color2, fontsize=10, ha='center', va='bottom')

# 网格线和圈颜色
ax.grid(color='#AAAAAA', linestyle='--', linewidth=0.7, alpha=0.7)
ax.spines['polar'].set_color('#666666')

# 图例与标题
ax.legend(['YOLOv11n','YOLOv11n+CHDWT'], loc='upper right', bbox_to_anchor=(1.05, 1.1), fontsize=10, frameon=False)
plt.title('YOLOv11n vs YOLOv11n+CHDWT', fontsize=14, pad=20)

# 保存高清图片
plt.tight_layout()
plt.savefig('YOLOv11n_vs_CHDWT_radar.png', dpi=500, bbox_inches='tight')
plt.show()
