from sympy import false

from ultralytics.models import NAS, RTDETR, SAM, YOLO, FastSAM, YOLOWorld
import torch
if __name__=="__main__":



    # 使用自己的YOLOv8.yamy文件搭建模型并加载预训练权重训练模型
    model = YOLO("/home/tgf/tgf/steel_default_detect/model/yolo_steel/ultralytics/cfg/models/11/yolo11_CHDWT_GLaM_LWGA.yaml")\
        # .load(r'E:\Part_time_job_orders\YOLO_NEW\YOLO11_All\ultralytics-main\yolo11n.pt')  # build from YAML and transfer weights

    results = model.train(data=r"/home/tgf/tgf/steel_default_detect/model/yolo_steel/ultralytics/cfg/datasets/VOC_my.yaml",
                          epochs=300,
                          imgsz=640,
                          batch=16,
                          # cache = False,
                          # single_cls = False,  # 是否是单类别检测
                          # workers = 0,
                          # resume=r'D:/model/yolov8/runs/detect/train/weights/last.pt',
                          amp = False
                          )

    # 使用YOLOv11.yamy文件搭建的模型训练
    # model = YOLO(r"D:\model\yolov11\ultralytics\cfg\models\11\yolo11_MDFM.yaml")  # build a new model from YAML
    # model.train(data=r'D:\model\yolov11\ultralytics\cfg\datasets\VOC_my.yaml',
    #                       epochs=300, imgsz=640, batch=1
    #             # , close_mosaic=10
    #             )

    # # 加载已训练好的模型权重搭建模型训练
    # model = YOLO(r'D:\bilibili\model\ultralytics-main\tests\yolov8n.pt')  # load a pretrained model (recommended for training)
    # results = model.train(data=r'D:\bilibili\model\ultralytics-main\ultralytics\cfg\datasets\VOC_my.yaml',
    #                       epochs=100, imgsz=640, batch=4)




